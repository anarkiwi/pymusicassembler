"""The loaded C64 memory image a parser works against.

:class:`SidImage` unwraps a PSID/RSID container (or a bare ``.prg``) into a full
64 KiB memory image with the tune placed at its load address, plus absolute-
addressed read accessors. This is the shared substitute for the per-parser
``_Image`` / ``load_sid`` / ``_memory_accessors`` helpers.
"""

from __future__ import annotations

import struct
from typing import List, Optional, Tuple

from vagrant_moses.memmap import IO_BASE, IO_LAST

from . import _scan
from .errors import SidParseError
from .header import SidHeader, parse_sid_header

MEM_SIZE = 0x10000


def load_prefix(addr: int) -> bytes:
    """The two-byte little-endian load address a ``.prg`` starts with."""
    return struct.pack("<H", addr & 0xFFFF)


def require_ram(start: int, length: int, what: str, error: type = SidParseError):
    """Raise ``error`` when ``what`` at ``[start, start+length)`` reaches the C64
    I/O area, where a C64 reads the VIC/SID/CIA chips instead of RAM."""
    if start <= IO_LAST and start + length > IO_BASE:
        raise error(
            f"{what} [{start:#06x},{start + length:#06x}) reaches the C64 I/O area "
            f"{IO_BASE:#06x}-{IO_LAST:#06x}, where the player reads live chips, not RAM"
        )


def parse_prg(raw: bytes, expected_load: Optional[int] = None) -> Tuple[int, bytes]:
    """Split a bare ``.prg`` workfile into ``(load_addr, body)``.

    The first two bytes are the little-endian load address; the rest is the
    image body. When ``expected_load`` is given and differs from the file's
    load address, :class:`SidParseError` is raised.
    """
    if len(raw) < 2:
        raise SidParseError("PRG too short for a load address")
    load = raw[0] | (raw[1] << 8)
    if expected_load is not None and load != expected_load:
        raise SidParseError(
            f"unexpected load address {load:#06x}, expected {expected_load:#06x}"
        )
    return load, bytes(raw[2:])


class SidImage:
    """A 64 KiB C64 memory image with the tune loaded at its load address.

    Attributes:
      mem: ``bytearray`` of length ``0x10000`` (the C64 address space).
      load: C64 address the image data starts at.
      end: one past the last loaded byte (``0x10000`` after an init run, which
        may have scattered data across memory).
      header: the parsed :class:`SidHeader`, or ``None`` for a bare ``.prg``.
      image: the raw C64 image bytes (player + data, without the container).
      container: the container bytes preceding ``image`` (PSID/RSID header plus
        any embedded 2-byte load address, or the ``.prg`` load-address prefix),
        kept so a writer can re-emit a byte-identical container.
    """

    __slots__ = ("mem", "load", "end", "header", "image", "container")

    def __init__(
        self,
        mem: bytearray,
        load: int,
        end: int,
        header: Optional[SidHeader],
        image: bytes,
        container: bytes,
    ):
        self.mem = mem
        self.load = load
        self.end = end
        self.header = header
        self.image = image
        self.container = container

    @classmethod
    def from_bytes(cls, data: bytes) -> "SidImage":
        """Load a PSID/RSID ``.sid`` or a bare ``.prg`` image from ``data``."""
        if data[:4] in (b"PSID", b"RSID"):
            return cls.from_sid(data)
        return cls.from_prg(data)

    @classmethod
    def from_sid(cls, data: bytes) -> "SidImage":
        """Load a PSID/RSID container into a 64 KiB image."""
        header = parse_sid_header(data)
        image = bytes(data[header.data_start :])
        container = bytes(data[: header.data_start])
        load = header.real_load_address
        return cls._place(image, load, header, container)

    @classmethod
    def from_prg(cls, data: bytes) -> "SidImage":
        """Load a bare ``.prg`` (2-byte little-endian load address + image)."""
        if len(data) < 2:
            raise SidParseError("PRG too short for a load address")
        load = data[0] | (data[1] << 8)
        return cls._place(bytes(data[2:]), load, None, bytes(data[:2]))

    @classmethod
    def _place(cls, image: bytes, load: int, header, container) -> "SidImage":
        end = load + len(image)
        if end > MEM_SIZE:
            raise SidParseError(
                f"data overruns memory (load {load:#06x}, {len(image)} bytes)"
            )
        mem = bytearray(MEM_SIZE)
        mem[load:end] = image
        return cls(mem, load, end, header, image, container)

    def byte(self, addr: int) -> int:
        """Read one byte at C64 ``addr`` (raises out of ``0..0xFFFF``)."""
        if not 0 <= addr < MEM_SIZE:
            raise SidParseError(f"address {addr:#06x} out of range")
        return self.mem[addr]

    def peek(self, addr: int, default: int = 0) -> int:
        """Read one byte at ``addr``, returning ``default`` if out of range."""
        if 0 <= addr < MEM_SIZE:
            return self.mem[addr]
        return default

    def word(self, addr: int) -> int:
        """Read a little-endian 16-bit word at C64 ``addr``."""
        return self.byte(addr) | (self.byte(addr + 1) << 8)

    def slice(self, addr: int, length: int) -> bytes:
        """Read ``length`` bytes starting at C64 ``addr`` (bounds-checked)."""
        if addr < 0 or addr + length > MEM_SIZE:
            raise SidParseError(f"slice at {addr:#06x}+{length} out of range")
        return bytes(self.mem[addr : addr + length])

    def ptr(self, lo_base: int, hi_base: int, index: int) -> int:
        """Read a split-pointer-table entry (``lo[index]`` + ``hi[index]<<8``)."""
        return self.peek(lo_base + index) | (self.peek(hi_base + index) << 8)

    def window(self, addr: int, size: int) -> bytes:
        """The ``size`` bytes a cursor reads from ``addr``, zero past ``$FFFF``."""
        return bytes(self.mem[addr : addr + size]).ljust(size, b"\0")

    def put_ptr(self, lo_base: int, hi_base: int, index: int, addr: int) -> None:
        """Point split-pointer-table entry ``index`` at ``addr`` (see :meth:`poke`)."""
        self.poke(lo_base + index, addr)
        self.poke(hi_base + index, addr >> 8)

    def contains(self, addr: int) -> bool:
        """True if ``addr`` lies within the loaded region (``load <= addr < end``)."""
        return self.load <= addr < self.end

    def byte_at(self, addr: int) -> int:
        """Read one byte at absolute C64 ``addr`` (raises out of ``0..0xFFFF``)."""
        return self.byte(addr)

    def word_at(self, addr: int) -> int:
        """Read a little-endian 16-bit word at absolute C64 ``addr``."""
        return self.word(addr)

    def poke(self, addr: int, value: int) -> None:
        """Write one byte at ``addr``, growing ``end`` on overrun.

        Writes before the load address raise :class:`SidParseError`; writes at
        or past ``end`` extend the loaded region.
        """
        if addr < self.load:
            raise SidParseError(f"poke at {addr:#06x} is before the load address")
        if addr >= MEM_SIZE:
            raise SidParseError(f"poke at {addr:#06x} out of range")
        self.mem[addr] = value & 0xFF
        if addr >= self.end:
            self.end = addr + 1

    def poke_bytes(self, addr: int, data: bytes) -> None:
        """Write ``data`` starting at ``addr`` (see :meth:`poke`)."""
        for offset, value in enumerate(data):
            self.poke(addr + offset, value)

    def to_prg(self) -> bytes:
        """Serialise to a bare ``.prg`` (LE load address + loaded image body)."""
        return load_prefix(self.load) + bytes(self.mem[self.load : self.end])

    def find(self, needle: bytes, start: Optional[int] = None) -> int:
        """First address of ``needle`` in the image, or ``-1``.

        Search starts at ``start`` (defaulting to the load address, so the
        container header is skipped).
        """
        return _scan.find_first(self.mem, needle, self.load if start is None else start)

    def find_all(self, needle: bytes, start: Optional[int] = None) -> List[int]:
        """Every address of ``needle`` in the image at or after ``start``."""
        return _scan.find_all(self.mem, needle, self.load if start is None else start)

    def find_split_table(self, lo, hi, *, min_length: int = 8) -> Optional[tuple]:
        """Locate a split lo/hi table anchor (see :func:`_scan.find_split_table`)."""
        return _scan.find_split_table(self.mem, lo, hi, min_length=min_length)

    def find_code(self, pattern, *, start: Optional[int] = None):
        """First masked code-fragment match of ``pattern`` (see :mod:`codescan`)."""
        from . import codescan

        return codescan.find_code_first(self, pattern, start=start)

    def find_code_all(self, pattern, *, start: Optional[int] = None) -> List:
        """Every masked code-fragment match of ``pattern`` (see :mod:`codescan`)."""
        from . import codescan

        return codescan.find_code_all(self, pattern, start=start)
